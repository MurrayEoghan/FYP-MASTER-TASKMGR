package models

type UserId struct {
	UserId int64 `schema:"id"`
}
