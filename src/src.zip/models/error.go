package models

type ErrorMessage struct {
	Message string `json:"message"`
}
