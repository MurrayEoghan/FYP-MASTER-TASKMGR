package followerModels

type UserIds struct {
	ParentId int `json:"parent_id"`
	SubId int `json:"sub_id"`
}