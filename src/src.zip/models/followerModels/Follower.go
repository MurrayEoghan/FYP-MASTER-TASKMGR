package followerModels

type Follower struct {
	Username string `json:"username"`
	Id int `json:"id"`
}