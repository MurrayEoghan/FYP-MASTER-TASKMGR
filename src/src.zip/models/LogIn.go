package models

type LogInUser struct {
	Username string `json:"username"`
	Password string `json:"password"`
}
