package followerModels

type Usernames struct {
	Username string `json:"username"`
}