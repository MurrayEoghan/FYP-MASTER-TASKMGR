package forumModels

type DeleteComment struct {
	CommentId int `json:"comment_id"`
}
