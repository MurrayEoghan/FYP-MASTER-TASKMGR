package forumModels

type AuthorId struct {
	AuthorId int `json:"author_id"`
}
