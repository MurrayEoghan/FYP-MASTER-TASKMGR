package forumModels

type PostId struct {
	PostId int `json:"post_id"`
}
